using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using MES仓储管理系统.Models;

namespace MES仓储管理系统
{
    public partial class 编辑用户 : Window
    {
        private readonly int _userId;
        private bool _isDefaultAdmin = false;

        public 编辑用户(int userId, Window owner)
        {
            InitializeComponent();
            _userId = userId;
            if (owner != null) this.Owner = owner;
            Loaded += async (s, e) => await LoadUserAsync();
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed) DragMove();
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private async Task LoadUserAsync()
        {
            try
            {
                var user = await Task.Run(() => AuthService.GetUserById(_userId));
                if (user == null)
                {
                    MessageBox.Show("用户不存在", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                    DialogResult = false;
                    return;
                }

                TxtUsername.Text = user.Username;
                TxtRealName.Text = user.RealName;
                TxtPhone.Text = user.Phone;
                TxtEmail.Text = user.Email;
                TblCreated.Text = user.CreatedTime.ToString("yyyy/MM/dd HH:mm");
                TblLastLogin.Text = user.LastLoginTime > DateTime.MinValue
                    ? user.LastLoginTime.ToString("yyyy/MM/dd HH:mm")
                    : "从未登录";

                // 检查是否是默认admin账号
                _isDefaultAdmin = user.Username == "admin";

                // 设置角色
                foreach (ComboBoxItem item in CmbRole.Items)
                {
                    if (item.Tag?.ToString() == ((int)user.Role).ToString())
                    {
                        CmbRole.SelectedItem = item;
                        break;
                    }
                }

                // admin账号角色不允许修改
                if (_isDefaultAdmin)
                {
                    CmbRole.IsEnabled = false;
                }

                // 设置状态
                foreach (ComboBoxItem item in CmbStatus.Items)
                {
                    if (item.Tag?.ToString() == user.IsActive.ToString())
                    {
                        CmbStatus.SelectedItem = item;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("加载用户信息失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                DialogResult = false;
            }
        }

        private async void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {
            string realName = TxtRealName.Text.Trim();
            string newPassword = TxtNewPassword.Password;
            string confirmPassword = TxtConfirmPassword.Password;
            string phone = TxtPhone.Text.Trim();
            string email = TxtEmail.Text.Trim();

            // 校验真实姓名
            if (string.IsNullOrEmpty(realName))
            {
                MessageBox.Show("请输入真实姓名", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtRealName.Focus();
                return;
            }

            // 校验邮箱格式（如果填了的话）
            if (!string.IsNullOrEmpty(email) && !IsValidEmail(email))
            {
                MessageBox.Show("邮箱格式不正确", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtEmail.Focus();
                return;
            }

            // 校验密码
            if (!string.IsNullOrEmpty(newPassword))
            {
                if (newPassword.Length < 6)
                {
                    MessageBox.Show("新密码长度至少6位", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                    TxtNewPassword.Focus();
                    return;
                }
                if (newPassword != confirmPassword)
                {
                    MessageBox.Show("两次输入的密码不一致", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                    TxtConfirmPassword.Focus();
                    return;
                }
            }

            // 选择角色
            var roleItem = CmbRole.SelectedItem as ComboBoxItem;
            if (roleItem?.Tag == null)
            {
                MessageBox.Show("请选择角色", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            int role = int.Parse(roleItem.Tag.ToString()!);

            // 选择状态
            var statusItem = CmbStatus.SelectedItem as ComboBoxItem;
            bool isActive = statusItem?.Tag?.ToString() == "True";

            try
            {
                bool success = await Task.Run(() => AuthService.UpdateUser(_userId, realName, role, phone, email, isActive, newPassword));
                if (success)
                {
                    MessageBox.Show("保存成功", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                    DialogResult = true;
                }
                else
                {
                    MessageBox.Show("保存失败", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("保存失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool IsValidEmail(string email)
        {
            return Regex.IsMatch(email, @"^[\w\.-]+@[\w\.-]+\.\w+$");
        }
    }
}
