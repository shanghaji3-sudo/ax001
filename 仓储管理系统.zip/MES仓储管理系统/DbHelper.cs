using System.Data;
using Microsoft.Data.Sqlite;

namespace MES仓储管理系统
{
    public static class DbHelper
    {
        private static readonly string connectionString = DatabaseInitializer.GetConnectionString();

        public static DataTable ExecuteQuery(string sql, SqliteParameter[]? parameters = null)
        {
            using var connection = new SqliteConnection(connectionString);
            connection.Open();
            using var command = new SqliteCommand(sql, connection);

            if (parameters != null)
                command.Parameters.AddRange(parameters);

            var dataTable = new DataTable();
            using var reader = command.ExecuteReader();
            dataTable.Load(reader);
            return dataTable;
        }

        public static bool TestConnection()
        {
            try
            {
                using var connection = new SqliteConnection(connectionString);
                connection.Open();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static int ExecuteNonQuery(string sql, SqliteParameter[]? parameters = null)
        {
            using var connection = new SqliteConnection(connectionString);
            connection.Open();
            using var command = new SqliteCommand(sql, connection);

            if (parameters != null)
                command.Parameters.AddRange(parameters);

            return command.ExecuteNonQuery();
        }
    }
}
