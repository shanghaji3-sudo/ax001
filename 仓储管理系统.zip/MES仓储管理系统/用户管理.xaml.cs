using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using MES仓储管理系统.Models;

namespace MES仓储管理系统
{
    public class UserListItem
    {
        public int Id { get; set; }
        public string Username { get; set; } = "";
        public string RealName { get; set; } = "";
        public string RoleName { get; set; } = "";
        public string Phone { get; set; } = "";
        public string Email { get; set; } = "";
        public bool IsActive { get; set; } = true;
        public string StatusText => IsActive ? "启用" : "禁用";
        public DateTime CreatedTime { get; set; }
    }

    public partial class 用户管理 : UserControl
    {
        public static RoutedUICommand SearchCommand = new RoutedUICommand("Search", "Search", typeof(用户管理));

        public 用户管理()
        {
            InitializeComponent();
            SearchCommand.InputGestures.Add(new KeyGesture(Key.Enter));
            CommandBindings.Add(new CommandBinding(SearchCommand, (s, e) => BtnSearch_Click(s, e)));
            Loaded += async (s, e) => await LoadUsersAsync();
        }

        private async Task LoadUsersAsync(string keyword = "")
        {
            try
            {
                LoadingPanel.Visibility = Visibility.Visible;
                UserDataGrid.Visibility = Visibility.Collapsed;

                var users = await Task.Run(() => AuthService.GetAllUsers(keyword));
                var list = users.Select(u => new UserListItem
                {
                    Id = u.Id,
                    Username = u.Username,
                    RealName = u.RealName,
                    RoleName = u.Role switch
                    {
                        UserRole.Admin => "管理员",
                        UserRole.WarehouseManager => "仓库主管",
                        UserRole.WarehouseStaff => "仓库员",
                        UserRole.Viewer => "查看员",
                        _ => "未知"
                    },
                    Phone = u.Phone,
                    Email = u.Email,
                    IsActive = u.IsActive,
                    CreatedTime = u.CreatedTime
                }).ToList();

                UserDataGrid.ItemsSource = list;
                LoadingPanel.Visibility = Visibility.Collapsed;
                UserDataGrid.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {
                MessageBox.Show("加载用户数据失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                LoadingPanel.Visibility = Visibility.Collapsed;
            }
        }

        private async void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            await LoadUsersAsync(TxtSearch.Text.Trim());
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var owner = Window.GetWindow(this);
            var dialog = new 新增用户(owner);
            if (dialog.ShowDialog() == true)
            {
                _ = LoadUsersAsync(TxtSearch.Text.Trim());
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selected = UserDataGrid.SelectedItem as UserListItem;
            if (selected == null)
            {
                MessageBox.Show("请先选择要编辑的用户", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var owner = Window.GetWindow(this);
            var dialog = new 编辑用户(selected.Id, owner);
            if (dialog.ShowDialog() == true)
            {
                _ = LoadUsersAsync(TxtSearch.Text.Trim());
            }
        }

        private async void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var selected = UserDataGrid.SelectedItem as UserListItem;
            if (selected == null)
            {
                MessageBox.Show("请先选择要删除的用户", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (selected.Id == CurrentUser.User?.Id)
            {
                MessageBox.Show("不能删除当前登录的用户", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (selected.Username == "admin")
            {
                MessageBox.Show("不能删除默认管理员账号", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var result = MessageBox.Show($"确定要删除用户 [{selected.RealName}] 吗？", "确认删除", 
                MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                bool success = await Task.Run(() => AuthService.DeleteUser(selected.Id));
                if (success)
                {
                    MessageBox.Show("删除成功", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                    await LoadUsersAsync(TxtSearch.Text.Trim());
                }
                else
                {
                    MessageBox.Show("删除失败", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private async void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            TxtSearch.Text = "";
            await LoadUsersAsync();
        }
    }
}
