using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using MES仓储管理系统.Models;

namespace MES仓储管理系统
{
    public partial class 主页面 : Page
    {
        private DispatcherTimer _timer;

        public 主页面()
        {
            InitializeComponent();
            ApplyPermissions();
            UpdateUserInfo();
            StartTimer();
            ContentBorder.Child = new 首页();
        }

        private void StartTimer()
        {
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += (s, e) =>
            {
                RunTime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            };
            _timer.Start();
            RunTime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }

        private void UpdateUserInfo()
        {
            if (CurrentUser.User != null)
            {
                TblUserInfo.Text = $"[{CurrentUser.User.RealName}] {CurrentUser.User.Role}";
            }
        }

        private void ApplyPermissions()
        {
            if (!CurrentUser.IsLoggedIn) return;

            BtnInbound.Visibility = CurrentUser.HasPermission(Permission.InboundView) ? Visibility.Visible : Visibility.Collapsed;
            BtnOutbound.Visibility = CurrentUser.HasPermission(Permission.OutboundView) ? Visibility.Visible : Visibility.Collapsed;
            BtnInventory.Visibility = CurrentUser.HasPermission(Permission.InventoryView) ? Visibility.Visible : Visibility.Collapsed;
            BtnReport.Visibility = CurrentUser.HasPermission(Permission.ReportView) ? Visibility.Visible : Visibility.Collapsed;
            BtnSettings.Visibility = (CurrentUser.IsAdmin || CurrentUser.User?.Role == UserRole.WarehouseManager) ? Visibility.Visible : Visibility.Collapsed;
            BtnUserManage.Visibility = CurrentUser.IsAdmin ? Visibility.Visible : Visibility.Collapsed;
        }

        private void BtnHome_Click(object sender, RoutedEventArgs e)
        {
            ContentBorder.Child = new 首页();
        }

        private void BtnInbound_Click(object sender, RoutedEventArgs e)
        {
            if (!CurrentUser.HasPermission(Permission.InboundView))
            {
                MessageBox.Show("您没有权限访问入库管理", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            ContentBorder.Child = new 入库管理();
        }

        private void BtnOutbound_Click(object sender, RoutedEventArgs e)
        {
            if (!CurrentUser.HasPermission(Permission.OutboundView))
            {
                MessageBox.Show("您没有权限访问出库管理", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            ContentBorder.Child = new 出库管理();
        }

        private void BtnInventory_Click(object sender, RoutedEventArgs e)
        {
            if (!CurrentUser.HasPermission(Permission.InventoryView))
            {
                MessageBox.Show("您没有权限访问库存管理", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            ContentBorder.Child = new 库存管理();
        }

        private void BtnReport_Click(object sender, RoutedEventArgs e)
        {
            if (!CurrentUser.HasPermission(Permission.ReportView))
            {
                MessageBox.Show("您没有权限访问报表统计", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            ContentBorder.Child = new 报表统计();
        }

        private void BtnSettings_Click(object sender, RoutedEventArgs e)
        {
            if (!(CurrentUser.IsAdmin || CurrentUser.User?.Role == UserRole.WarehouseManager))
            {
                MessageBox.Show("您没有权限访问系统设置", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            ContentBorder.Child = new 系统设置();
        }

        private void BtnUserManage_Click(object sender, RoutedEventArgs e)
        {
            if (!CurrentUser.IsAdmin)
            {
                MessageBox.Show("您没有权限访问用户管理", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            ContentBorder.Child = new 用户管理();
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("确定要退出登录吗？", "确认退出", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                _timer?.Stop();
                CurrentUser.Logout();
                var loginWindow = new LoginWindow();
                loginWindow.Show();
                Window.GetWindow(this)?.Close();
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
