﻿using System.Data;
using Microsoft.Data.Sqlite;
using System.Windows;
using System.Windows.Controls;
using MES仓储管理系统.Models;

namespace MES仓储管理系统
{
    public partial class 出库管理 : UserControl
    {
        private CancellationTokenSource? _cts;

        public 出库管理()
        {
            InitializeComponent();
            ApplyPermissions();
            Loaded += OutboundManagement_Loaded;
        }

        private void ApplyPermissions()
        {
            var user = CurrentUser.User;
            if (user == null) return;
            BtnAddOutbound.Visibility = user.HasPermission(Permission.OutboundCreate) ? Visibility.Visible : Visibility.Collapsed;
            BtnEditOutbound.Visibility = user.HasPermission(Permission.OutboundEdit) ? Visibility.Visible : Visibility.Collapsed;
            BtnDeleteOutbound.Visibility = user.HasPermission(Permission.OutboundDelete) ? Visibility.Visible : Visibility.Collapsed;
        }

        private void OutboundManagement_Loaded(object sender, RoutedEventArgs e) => LoadDataAsync();

        private async void LoadDataAsync()
        {
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            LoadingPanel.Visibility = Visibility.Visible;
            OutboundDataGrid.Visibility = Visibility.Collapsed;
            try
            {
                var dataTable = await Task.Run(() => DbHelper.ExecuteQuery("SELECT * FROM 出库"), token);
                if (!token.IsCancellationRequested)
                {
                    OutboundDataGrid.ItemsSource = dataTable.DefaultView;
                    LoadingPanel.Visibility = Visibility.Collapsed;
                    OutboundDataGrid.Visibility = Visibility.Visible;
                }
            }
            catch (Exception ex)
            {
                if (!token.IsCancellationRequested)
                {
                    MessageBox.Show("数据库连接失败：" + ex.Message, "连接失败", MessageBoxButton.OK, MessageBoxImage.Error);
                    LoadingPanel.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e) => LoadDataAsync();

        private void BtnAddOutbound_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new 出库管理_新增出库 { Owner = Window.GetWindow(this) };
            if (dialog.ShowDialog() == true) SaveOutboundToDatabase(dialog);
        }

        private void BtnEditOutbound_Click(object sender, RoutedEventArgs e)
        {
            if (OutboundDataGrid.SelectedItem is not DataRowView selectedRow)
            {
                MessageBox.Show("请先选择要编辑的行", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var dialog = new 出库管理_编辑 { Owner = Window.GetWindow(this) };
            dialog.LoadData(selectedRow);
            if (dialog.ShowDialog() == true) UpdateOutboundToDatabase(dialog, selectedRow["出库单号"]?.ToString() ?? "");
        }

        private async void SaveOutboundToDatabase(出库管理_新增出库 dialog)
        {
            try
            {
                var sql = @"INSERT INTO 出库 (出库单号, 物料名称, 物料编码, 数量, 仓库, 出库时间, 操作人, 状态)
                            VALUES (@OutboundNo, @MaterialName, @MaterialCode, @Quantity, @Warehouse, @OutboundTime, @Operator, @Status)";
                var parameters = new[]
                {
                    new SqliteParameter("@OutboundNo", dialog.OutboundNo), new SqliteParameter("@MaterialName", dialog.MaterialName),
                    new SqliteParameter("@MaterialCode", dialog.MaterialCode), new SqliteParameter("@Quantity", int.Parse(dialog.Quantity)),
                    new SqliteParameter("@Warehouse", dialog.Warehouse), new SqliteParameter("@OutboundTime", DateTime.Parse(dialog.OutboundTime)),
                    new SqliteParameter("@Operator", dialog.Operator), new SqliteParameter("@Status", dialog.Status)
                };
                await Task.Run(() => DbHelper.ExecuteNonQuery(sql, parameters));
                MessageBox.Show("出库记录保存成功！", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadDataAsync();
            }
            catch (Exception ex) { MessageBox.Show("保存失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private async void UpdateOutboundToDatabase(出库管理_编辑 dialog, string outboundNo)
        {
            try
            {
                var sql = @"UPDATE 出库 SET 物料名称=@MaterialName, 物料编码=@MaterialCode, 数量=@Quantity,
                            仓库=@Warehouse, 出库时间=@OutboundTime, 操作人=@Operator, 状态=@Status WHERE 出库单号=@OutboundNo";
                var parameters = new[]
                {
                    new SqliteParameter("@OutboundNo", outboundNo), new SqliteParameter("@MaterialName", dialog.MaterialName),
                    new SqliteParameter("@MaterialCode", dialog.MaterialCode), new SqliteParameter("@Quantity", int.Parse(dialog.Quantity)),
                    new SqliteParameter("@Warehouse", dialog.Warehouse), new SqliteParameter("@OutboundTime", DateTime.Parse(dialog.OutboundTime)),
                    new SqliteParameter("@Operator", dialog.Operator), new SqliteParameter("@Status", dialog.Status)
                };
                await Task.Run(() => DbHelper.ExecuteNonQuery(sql, parameters));
                MessageBox.Show("出库记录更新成功！", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadDataAsync();
            }
            catch (Exception ex) { MessageBox.Show("更新失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void BtnDeleteOutbound_Click(object sender, RoutedEventArgs e)
        {
            if (OutboundDataGrid.SelectedItem is not DataRowView selectedRow)
            {
                MessageBox.Show("请先选择要删除的行", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var outboundNo = selectedRow["出库单号"]?.ToString() ?? "";
            var materialName = selectedRow["物料名称"]?.ToString() ?? "";
            if (MessageBox.Show($"确定要删除出库单号为 [{outboundNo}]、物料名称为 [{materialName}] 的记录吗？",
                "确认删除", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                DeleteOutboundFromDatabase(outboundNo);
        }

        private async void DeleteOutboundFromDatabase(string outboundNo)
        {
            try
            {
                var sql = "DELETE FROM 出库 WHERE 出库单号=@OutboundNo";
                var parameters = new[] { new SqliteParameter("@OutboundNo", outboundNo) };
                await Task.Run(() => DbHelper.ExecuteNonQuery(sql, parameters));
                MessageBox.Show("出库记录删除成功！", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadDataAsync();
            }
            catch (Exception ex) { MessageBox.Show("删除失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error); }
        }
    }
}
