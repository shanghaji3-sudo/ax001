﻿using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Input;
using MES仓储管理系统.Models;
using Microsoft.Data.Sqlite;

namespace MES仓储管理系统
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
            TxtUsername.Focus();
        }

        private void TxtUsername_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                TxtPassword.Focus();
        }

        private void TxtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                BtnLogin_Click(sender, e);
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private async void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            TblError.Visibility = Visibility.Collapsed;
            BtnLogin.IsEnabled = false;
            BtnLogin.Content = "登录中...";

            string username = TxtUsername.Text.Trim();
            string password = TxtPassword.Password;

            if (string.IsNullOrEmpty(username))
            {
                ShowError("请输入用户名");
                return;
            }
            if (string.IsNullOrEmpty(password))
            {
                ShowError("请输入密码");
                return;
            }

            try
            {
                var user = await Task.Run(() => AuthService.Login(username, password));
                if (user != null)
                {
                    CurrentUser.Login(user);
                    await Task.Run(() => AuthService.LogLogin(user.Id, true, ""));
                    var mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Close();
                }
                else
                {
                    ShowError("用户名或密码错误");
                    await Task.Run(() => AuthService.LogLogin(0, false, username));
                }
            }
            catch (Exception ex)
            {
                ShowError("登录失败：" + ex.Message);
            }
            finally
            {
                BtnLogin.IsEnabled = true;
                BtnLogin.Content = "登 录";
            }
        }

        private void ForgotPassword_Click(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("请联系管理员重置密码", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ShowError(string message)
        {
            TblError.Text = message;
            TblError.Visibility = Visibility.Visible;
            System.Diagnostics.Debug.WriteLine("[LoginError] " + message);
        }
    }

    public static class AuthService
    {
        private static readonly string connectionString = DatabaseInitializer.GetConnectionString();

        public static User? Login(string username, string password)
        {
            string passwordHash = HashPassword(password);

            User? user = null;

            using (var conn = new SqliteConnection(connectionString))
            {
                conn.Open();

                string sql = @"SELECT Id, Username, PasswordHash, RealName, Role, Phone, Email, IsActive, LastLoginTime, CreatedTime, CreatedBy 
                              FROM Users WHERE Username=@Username AND PasswordHash=@PasswordHash AND IsActive=1";

                using var cmd = new SqliteCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@PasswordHash", passwordHash);

                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    user = new User
                    {
                        Id = reader.GetInt32(0),
                        Username = reader.GetString(1),
                        PasswordHash = reader.GetString(2),
                        RealName = reader.GetString(3),
                        Role = (UserRole)reader.GetInt32(4),
                        Phone = reader.IsDBNull(5) ? "" : reader.GetString(5),
                        Email = reader.IsDBNull(6) ? "" : reader.GetString(6),
                        IsActive = !reader.IsDBNull(7) && reader.GetInt32(7) == 1,
                        LastLoginTime = reader.IsDBNull(8) ? DateTime.MinValue : DateTime.Parse(reader.GetString(8)),
                        CreatedTime = DateTime.Parse(reader.GetString(9)),
                        CreatedBy = reader.GetInt32(10)
                    };
                }
            }

            if (user != null)
            {
                UpdateLastLogin(user.Id);
            }

            return user;
        }

        private static void UpdateLastLogin(int userId)
        {
            using var conn = new SqliteConnection(connectionString);
            conn.Open();
            string sql = "UPDATE Users SET LastLoginTime=datetime('now','localtime') WHERE Id=@Id";
            using var cmd = new SqliteCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", userId);
            cmd.ExecuteNonQuery();
        }

        public static void LogLogin(int userId, bool success, string username)
        {
            try
            {
                using var conn = new SqliteConnection(connectionString);
                conn.Open();
                string sql = @"INSERT INTO LoginLogs (UserId, Username, LoginTime, IsSuccess, IpAddress)
                              VALUES (@UserId, @Username, datetime('now','localtime'), @Success, @Ip)";
                using var cmd = new SqliteCommand(sql, conn);
                cmd.Parameters.AddWithValue("@UserId", userId);
                cmd.Parameters.AddWithValue("@Username", username ?? "");
                cmd.Parameters.AddWithValue("@Success", success ? 1 : 0);
                cmd.Parameters.AddWithValue("@Ip", GetLocalIp());
                cmd.ExecuteNonQuery();
            }
            catch { }
        }

        private static string GetLocalIp()
        {
            try
            {
                var host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
                foreach (var ip in host.AddressList)
                {
                    if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        return ip.ToString();
                }
            }
            catch { }
            return "127.0.0.1";
        }

        public static string HashPassword(string password)
        {
            using var sha256 = SHA256.Create();
            var bytes = Encoding.UTF8.GetBytes(password + "MES_SALT_2024");
            var hash = sha256.ComputeHash(bytes);
            return Convert.ToBase64String(hash);
        }

        public static User? GetUserById(int userId)
        {
            using var conn = new SqliteConnection(connectionString);
            conn.Open();

            string sql = @"SELECT Id, Username, PasswordHash, RealName, Role, Phone, Email, IsActive, LastLoginTime, CreatedTime, CreatedBy 
                          FROM Users WHERE Id=@Id";

            using var cmd = new SqliteCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", userId);

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return new User
                {
                    Id = reader.GetInt32(0),
                    Username = reader.GetString(1),
                    PasswordHash = reader.GetString(2),
                    RealName = reader.GetString(3),
                    Role = (UserRole)reader.GetInt32(4),
                    Phone = reader.IsDBNull(5) ? "" : reader.GetString(5),
                    Email = reader.IsDBNull(6) ? "" : reader.GetString(6),
                    IsActive = !reader.IsDBNull(7) && reader.GetInt32(7) == 1,
                    LastLoginTime = reader.IsDBNull(8) ? DateTime.MinValue : DateTime.Parse(reader.GetString(8)),
                    CreatedTime = DateTime.Parse(reader.GetString(9)),
                    CreatedBy = reader.GetInt32(10)
                };
            }
            return null;
        }

        public static bool ChangePassword(int userId, string oldPassword, string newPassword)
        {
            string oldHash = HashPassword(oldPassword);
            string newHash = HashPassword(newPassword);

            using var conn = new SqliteConnection(connectionString);
            conn.Open();

            string checkSql = "SELECT COUNT(1) FROM Users WHERE Id=@Id AND PasswordHash=@OldHash";
            using var checkCmd = new SqliteCommand(checkSql, conn);
            checkCmd.Parameters.AddWithValue("@Id", userId);
            checkCmd.Parameters.AddWithValue("@OldHash", oldHash);
            long count = (long)(checkCmd.ExecuteScalar() ?? 0);
            if (count == 0) return false;

            string updateSql = "UPDATE Users SET PasswordHash=@NewHash WHERE Id=@Id";
            using var updateCmd = new SqliteCommand(updateSql, conn);
            updateCmd.Parameters.AddWithValue("@Id", userId);
            updateCmd.Parameters.AddWithValue("@NewHash", newHash);
            updateCmd.ExecuteNonQuery();
            return true;
        }

        public static List<User> GetAllUsers(string keyword = "")
        {
            var list = new List<User>();
            using var conn = new SqliteConnection(connectionString);
            conn.Open();

            string sql = @"SELECT Id, Username, PasswordHash, RealName, Role, Phone, Email, IsActive, LastLoginTime, CreatedTime, CreatedBy 
                          FROM Users";
            if (!string.IsNullOrEmpty(keyword))
            {
                sql += " WHERE Username LIKE @Keyword OR RealName LIKE @Keyword OR Phone LIKE @Keyword";
            }
            sql += " ORDER BY Id";

            using var cmd = new SqliteCommand(sql, conn);
            if (!string.IsNullOrEmpty(keyword))
            {
                cmd.Parameters.AddWithValue("@Keyword", $"%{keyword}%");
            }

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new User
                {
                    Id = reader.GetInt32(0),
                    Username = reader.GetString(1),
                    PasswordHash = reader.GetString(2),
                    RealName = reader.GetString(3),
                    Role = (UserRole)reader.GetInt32(4),
                    Phone = reader.IsDBNull(5) ? "" : reader.GetString(5),
                    Email = reader.IsDBNull(6) ? "" : reader.GetString(6),
                    IsActive = !reader.IsDBNull(7) && reader.GetInt32(7) == 1,
                    LastLoginTime = reader.IsDBNull(8) ? DateTime.MinValue : DateTime.Parse(reader.GetString(8)),
                    CreatedTime = DateTime.Parse(reader.GetString(9)),
                    CreatedBy = reader.GetInt32(10)
                });
            }
            return list;
        }

        public static bool CreateUser(string username, string password, string realName, int role, string phone, string email)
        {
            using var conn = new SqliteConnection(connectionString);
            conn.Open();

            string hash = HashPassword(password);
            string sql = @"INSERT INTO Users (Username, PasswordHash, RealName, Role, Phone, Email, IsActive, CreatedTime, CreatedBy)
                          VALUES (@Username, @Hash, @RealName, @Role, @Phone, @Email, 1, datetime('now','localtime'), @CreatedBy)";

            using var cmd = new SqliteCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Hash", hash);
            cmd.Parameters.AddWithValue("@RealName", realName);
            cmd.Parameters.AddWithValue("@Role", role);
            cmd.Parameters.AddWithValue("@Phone", phone);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@CreatedBy", CurrentUser.User?.Id ?? 0);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0;
        }

        public static bool UpdateUser(int userId, string realName, int role, string phone, string email, bool isActive, string? newPassword = null)
        {
            using var conn = new SqliteConnection(connectionString);
            conn.Open();

            string sql = @"UPDATE Users SET RealName=@RealName, Role=@Role, Phone=@Phone, Email=@Email, IsActive=@IsActive";
            if (!string.IsNullOrEmpty(newPassword))
            {
                sql += ", PasswordHash=@Hash";
            }
            sql += " WHERE Id=@Id";

            using var cmd = new SqliteCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", userId);
            cmd.Parameters.AddWithValue("@RealName", realName);
            cmd.Parameters.AddWithValue("@Role", role);
            cmd.Parameters.AddWithValue("@Phone", phone);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@IsActive", isActive ? 1 : 0);
            if (!string.IsNullOrEmpty(newPassword))
            {
                cmd.Parameters.AddWithValue("@Hash", HashPassword(newPassword));
            }

            int rows = cmd.ExecuteNonQuery();
            return rows > 0;
        }

        public static bool DeleteUser(int userId)
        {
            using var conn = new SqliteConnection(connectionString);
            conn.Open();
            string sql = "DELETE FROM Users WHERE Id=@Id";
            using var cmd = new SqliteCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", userId);
            int rows = cmd.ExecuteNonQuery();
            return rows > 0;
        }
    }
}
