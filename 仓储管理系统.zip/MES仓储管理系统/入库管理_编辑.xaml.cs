using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace MES仓储管理系统
{
    public partial class 入库管理_编辑 : Window
    {
        public bool IsConfirmed { get; private set; }
        public string InboundNo => TxtInboundNo.Text.Trim();
        public string MaterialName => TxtMaterialName.Text.Trim();
        public string MaterialCode => TxtMaterialCode.Text.Trim();
        public string Quantity => TxtQuantity.Text.Trim();
        public string Warehouse => (CmbWarehouse.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";
        public string InboundTime => DpInboundTime.SelectedDate?.ToString("yyyy-MM-dd") ?? "";
        public string Operator => TxtOperator.Text.Trim();
        public string Status => (CmbStatus.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";

        public 入库管理_编辑()
        {
            InitializeComponent();
            IsConfirmed = false;
        }

        public void LoadData(DataRowView row)
        {
            TxtInboundNo.Text = row["入库单号"]?.ToString() ?? "";
            TxtMaterialName.Text = row["物料名称"]?.ToString() ?? "";
            TxtMaterialCode.Text = row["物料编码"]?.ToString() ?? "";
            TxtQuantity.Text = row["数量"]?.ToString() ?? "";
            CmbWarehouse.Text = row["仓库"]?.ToString() ?? "";
            if (DateTime.TryParse(row["入库时间"]?.ToString(), out var dt))
                DpInboundTime.SelectedDate = dt;
            TxtOperator.Text = row["操作人"]?.ToString() ?? "";
            CmbStatus.Text = row["状态"]?.ToString() ?? "";
        }

        private void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(MaterialName))
            {
                MessageBox.Show("物料名称不能为空", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtMaterialName.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(MaterialCode))
            {
                MessageBox.Show("物料编码不能为空", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtMaterialCode.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(Quantity))
            {
                MessageBox.Show("数量不能为空", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtQuantity.Focus();
                return;
            }
            if (!int.TryParse(Quantity, out _))
            {
                MessageBox.Show("数量必须为整数", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtQuantity.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(Warehouse))
            {
                MessageBox.Show("请选择仓库", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                CmbWarehouse.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(InboundTime))
            {
                MessageBox.Show("入库时间不能为空", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                DpInboundTime.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(Operator))
            {
                MessageBox.Show("操作人不能为空", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtOperator.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(Status))
            {
                MessageBox.Show("状态不能为空", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                CmbStatus.Focus();
                return;
            }

            IsConfirmed = true;
            DialogResult = true;
            Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            IsConfirmed = false;
            DialogResult = false;
            Close();
        }
    }
}