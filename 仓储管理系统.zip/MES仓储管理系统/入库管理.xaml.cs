﻿using System.Data;
using Microsoft.Data.Sqlite;
using System.Windows;
using System.Windows.Controls;
using MES仓储管理系统.Models;

namespace MES仓储管理系统
{
    public partial class 入库管理 : UserControl
    {
        private CancellationTokenSource? _cts;

        public 入库管理()
        {
            InitializeComponent();
            ApplyPermissions();
            Loaded += InboundManagement_Loaded;
        }

        private void ApplyPermissions()
        {
            var user = CurrentUser.User;
            if (user == null) return;
            BtnAddInbound.Visibility = user.HasPermission(Permission.InboundCreate) ? Visibility.Visible : Visibility.Collapsed;
            BtnEditInbound.Visibility = user.HasPermission(Permission.InboundEdit) ? Visibility.Visible : Visibility.Collapsed;
            BtnDeleteInbound.Visibility = user.HasPermission(Permission.InboundDelete) ? Visibility.Visible : Visibility.Collapsed;
        }

        private void InboundManagement_Loaded(object sender, RoutedEventArgs e) => LoadDataAsync();

        private async void LoadDataAsync()
        {
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            LoadingPanel.Visibility = Visibility.Visible;
            InboundDataGrid.Visibility = Visibility.Collapsed;
            try
            {
                var dataTable = await Task.Run(() => DbHelper.ExecuteQuery("SELECT * FROM 入库"), token);
                if (!token.IsCancellationRequested)
                {
                    InboundDataGrid.ItemsSource = dataTable.DefaultView;
                    LoadingPanel.Visibility = Visibility.Collapsed;
                    InboundDataGrid.Visibility = Visibility.Visible;
                }
            }
            catch (Exception ex)
            {
                if (!token.IsCancellationRequested)
                {
                    MessageBox.Show("数据库连接失败：" + ex.Message, "连接失败", MessageBoxButton.OK, MessageBoxImage.Error);
                    LoadingPanel.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e) => LoadDataAsync();

        private void BtnAddInbound_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new 入库管理_新增入库 { Owner = Window.GetWindow(this) };
            if (dialog.ShowDialog() == true) SaveInboundToDatabase(dialog);
        }

        private void BtnEditInbound_Click(object sender, RoutedEventArgs e)
        {
            if (InboundDataGrid.SelectedItem is not DataRowView selectedRow)
            {
                MessageBox.Show("请先选择要编辑的行", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var dialog = new 入库管理_编辑 { Owner = Window.GetWindow(this) };
            dialog.LoadData(selectedRow);
            if (dialog.ShowDialog() == true) UpdateInboundToDatabase(dialog, selectedRow["入库单号"]?.ToString() ?? "");
        }

        private async void SaveInboundToDatabase(入库管理_新增入库 dialog)
        {
            try
            {
                var sql = @"INSERT INTO 入库 (入库单号, 物料名称, 物料编码, 数量, 仓库, 入库时间, 操作人, 状态)
                            VALUES (@InboundNo, @MaterialName, @MaterialCode, @Quantity, @Warehouse, @InboundTime, @Operator, @Status)";
                var parameters = new[]
                {
                    new SqliteParameter("@InboundNo", dialog.InboundNo), new SqliteParameter("@MaterialName", dialog.MaterialName),
                    new SqliteParameter("@MaterialCode", dialog.MaterialCode), new SqliteParameter("@Quantity", int.Parse(dialog.Quantity)),
                    new SqliteParameter("@Warehouse", dialog.Warehouse), new SqliteParameter("@InboundTime", DateTime.Parse(dialog.InboundTime)),
                    new SqliteParameter("@Operator", dialog.Operator), new SqliteParameter("@Status", dialog.Status)
                };
                await Task.Run(() => DbHelper.ExecuteNonQuery(sql, parameters));
                MessageBox.Show("入库记录保存成功！", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadDataAsync();
            }
            catch (Exception ex) { MessageBox.Show("保存失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private async void UpdateInboundToDatabase(入库管理_编辑 dialog, string inboundNo)
        {
            try
            {
                var sql = @"UPDATE 入库 SET 物料名称=@MaterialName, 物料编码=@MaterialCode, 数量=@Quantity,
                            仓库=@Warehouse, 入库时间=@InboundTime, 操作人=@Operator, 状态=@Status WHERE 入库单号=@InboundNo";
                var parameters = new[]
                {
                    new SqliteParameter("@InboundNo", inboundNo), new SqliteParameter("@MaterialName", dialog.MaterialName),
                    new SqliteParameter("@MaterialCode", dialog.MaterialCode), new SqliteParameter("@Quantity", int.Parse(dialog.Quantity)),
                    new SqliteParameter("@Warehouse", dialog.Warehouse), new SqliteParameter("@InboundTime", DateTime.Parse(dialog.InboundTime)),
                    new SqliteParameter("@Operator", dialog.Operator), new SqliteParameter("@Status", dialog.Status)
                };
                await Task.Run(() => DbHelper.ExecuteNonQuery(sql, parameters));
                MessageBox.Show("入库记录更新成功！", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadDataAsync();
            }
            catch (Exception ex) { MessageBox.Show("更新失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void BtnDeleteInbound_Click(object sender, RoutedEventArgs e)
        {
            if (InboundDataGrid.SelectedItem is not DataRowView selectedRow)
            {
                MessageBox.Show("请先选择要删除的行", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var inboundNo = selectedRow["入库单号"]?.ToString() ?? "";
            var materialName = selectedRow["物料名称"]?.ToString() ?? "";
            if (MessageBox.Show($"确定要删除入库单号为 [{inboundNo}]、物料名称为 [{materialName}] 的记录吗？",
                "确认删除", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                DeleteInboundFromDatabase(inboundNo);
        }

        private async void DeleteInboundFromDatabase(string inboundNo)
        {
            try
            {
                var sql = "DELETE FROM 入库 WHERE 入库单号=@InboundNo";
                var parameters = new[] { new SqliteParameter("@InboundNo", inboundNo) };
                await Task.Run(() => DbHelper.ExecuteNonQuery(sql, parameters));
                MessageBox.Show("入库记录删除成功！", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadDataAsync();
            }
            catch (Exception ex) { MessageBox.Show("删除失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error); }
        }
    }
}
