using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using MES仓储管理系统.Models;

namespace MES仓储管理系统
{
    public partial class 新增用户 : Window
    {
        public 新增用户(Window owner)
        {
            InitializeComponent();
            if (owner != null) this.Owner = owner;
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed) DragMove();
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private async void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {
            string username = TxtUsername.Text.Trim();
            string realName = TxtRealName.Text.Trim();
            string password = TxtPassword.Password;
            string confirmPassword = TxtConfirmPassword.Password;
            string phone = TxtPhone.Text.Trim();
            string email = TxtEmail.Text.Trim();

            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("请输入用户名", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtUsername.Focus();
                return;
            }
            if (string.IsNullOrEmpty(realName))
            {
                MessageBox.Show("请输入真实姓名", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtRealName.Focus();
                return;
            }
            if (string.IsNullOrEmpty(password))
            {
                MessageBox.Show("请输入密码", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtPassword.Focus();
                return;
            }
            if (password.Length < 6)
            {
                MessageBox.Show("密码长度至少6位", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtPassword.Focus();
                return;
            }
            if (password != confirmPassword)
            {
                MessageBox.Show("两次输入的密码不一致", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtConfirmPassword.Focus();
                return;
            }
            if (!string.IsNullOrEmpty(email) && !IsValidEmail(email))
            {
                MessageBox.Show("邮箱格式不正确", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtEmail.Focus();
                return;
            }

            var selectedItem = CmbRole.SelectedItem as ComboBoxItem;
            if (selectedItem?.Tag == null)
            {
                MessageBox.Show("请选择角色", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            int role = int.Parse(selectedItem.Tag.ToString()!);

            try
            {
                bool success = await Task.Run(() => AuthService.CreateUser(username, password, realName, role, phone, email));
                if (success)
                {
                    MessageBox.Show("创建成功", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                    DialogResult = true;
                }
                else
                {
                    MessageBox.Show("创建失败，用户名可能已存在", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("创建失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool IsValidEmail(string email)
        {
            return Regex.IsMatch(email, @"^[\w\.-]+@[\w\.-]+\.\w+$");
        }
    }
}
