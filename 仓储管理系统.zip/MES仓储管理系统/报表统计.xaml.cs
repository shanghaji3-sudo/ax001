using System.Collections.Generic;
using System.Data;
using Microsoft.Data.Sqlite;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;
using MES仓储管理系统.Models;

namespace MES仓储管理系统
{
    public partial class 报表统计 : UserControl
    {
        private enum DateFilterType { Year, Month, Day }
        private DateFilterType _currentFilter = DateFilterType.Year;
        private int _selectedYear = DateTime.Now.Year;
        private int _selectedMonth = DateTime.Now.Month;
        private DateTime _selectedDay = DateTime.Now.Date;

        public 报表统计()
        {
            InitializeComponent();
            ApplyPermissions();
            Loaded += ReportStatistics_Loaded;
        }

        private void ApplyPermissions()
        {
            var user = CurrentUser.User;
            if (user == null) return;

            BtnExportReport.Visibility = user.HasPermission(Permission.ReportExport) ? Visibility.Visible : Visibility.Collapsed;
        }

        private void ReportStatistics_Loaded(object sender, RoutedEventArgs e)
        {
            InitYearCombo();
            InitMonthCombo();
            LoadData();
        }

        private void InitYearCombo()
        {
            CmbYear.Items.Clear();
            int currentYear = DateTime.Now.Year;
            for (int i = currentYear; i >= currentYear - 9; i--)
            {
                CmbYear.Items.Add(i);
            }
            CmbYear.SelectedItem = _selectedYear;
        }

        private void InitMonthCombo()
        {
            CmbMonth.Items.Clear();
            for (int i = 1; i <= 12; i++)
            {
                CmbMonth.Items.Add($"{i}月");
            }
            CmbMonth.SelectedIndex = _selectedMonth - 1;
        }

        private void DateFilter_Checked(object sender, RoutedEventArgs e)
        {
            if (TblMonthLabel == null || CmbMonth == null || CmbYear == null)
                return;

            if (RbYear.IsChecked == true)
            {
                _currentFilter = DateFilterType.Year;
                TblMonthLabel.Visibility = Visibility.Collapsed;
                CmbMonth.Visibility = Visibility.Collapsed;
            }
            else if (RbMonth.IsChecked == true)
            {
                _currentFilter = DateFilterType.Month;
                TblMonthLabel.Visibility = Visibility.Visible;
                CmbMonth.Visibility = Visibility.Visible;
            }
            else if (RbDay.IsChecked == true)
            {
                _currentFilter = DateFilterType.Day;
                TblMonthLabel.Visibility = Visibility.Visible;
                CmbMonth.Visibility = Visibility.Visible;
            }
            LoadData();
        }

        private void CmbYear_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbYear.SelectedItem is int year)
            {
                _selectedYear = year;
                LoadData();
            }
        }

        private void CmbMonth_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbMonth == null) return;
            if (CmbMonth.SelectedIndex >= 0)
            {
                _selectedMonth = CmbMonth.SelectedIndex + 1;
                LoadData();
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private async void BtnExportReport_Click(object sender, RoutedEventArgs e)
        {
            var data = await GetStatisticsDataAsync();
            if (data == null || data.Count == 0)
            {
                MessageBox.Show("没有数据可导出", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string filterLabel = _currentFilter switch
            {
                DateFilterType.Year => $"{_selectedYear - 9}-{_selectedYear}年",
                DateFilterType.Month => $"{_selectedYear}年",
                DateFilterType.Day => $"{_selectedYear}年{_selectedMonth}月",
                _ => ""
            };

            var dlg = new SaveFileDialog
            {
                FileName = $"出入库报表_{filterLabel}",
                DefaultExt = ".xls",
                Filter = "Excel 文件 (*.xls)|*.xls|所有文件 (*.*)|*.*"
            };

            if (dlg.ShowDialog() != true) return;

            try
            {
                string xml = BuildExcelXml(data, filterLabel);
                File.WriteAllText(dlg.FileName, xml, Encoding.UTF8);
                MessageBox.Show($"报表已成功导出到：\n{dlg.FileName}", "导出成功", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("导出失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string BuildExcelXml(List<StatData> data, string filterLabel)
        {
            var sb = new StringBuilder();
            string reportTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
            string userName = CurrentUser.User?.RealName ?? "";
            string roleName = CurrentUser.User?.Role.ToString() ?? "";

            sb.AppendLine("<?xml version=\"1.0\"?>");
            sb.AppendLine("<?mso-application progid=\"Excel.Sheet\"?>");
            sb.AppendLine("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\"");
            sb.AppendLine(" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\">");

            // 样式定义
            sb.AppendLine("<Styles>");
            sb.AppendLine("<Style ss:ID=\"sTitle\"><Font ss:Size=\"16\" ss:Bold=\"1\" ss:Color=\"#1A1A2E\"/><Alignment ss:Horizontal=\"Center\"/></Style>");
            sb.AppendLine("<Style ss:ID=\"sSubtitle\"><Font ss:Size=\"10\" ss:Color=\"#666666\"/><Alignment ss:Horizontal=\"Center\"/></Style>");
            sb.AppendLine("<Style ss:ID=\"sHeader\"><Font ss:Size=\"11\" ss:Bold=\"1\" ss:Color=\"#FFFFFF\"/><Interior ss:Color=\"#0A2463\" ss:Pattern=\"Solid\"/><Alignment ss:Horizontal=\"Center\"/><Borders><Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#999999\"/></Borders></Style>");
            sb.AppendLine("<Style ss:ID=\"sData\"><Font ss:Size=\"10\"/><Alignment ss:Horizontal=\"Center\"/><Borders><Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#DDDDDD\"/></Borders></Style>");
            sb.AppendLine("<Style ss:ID=\"sDataAlt\"><Font ss:Size=\"10\"/><Interior ss:Color=\"#F5F5F5\" ss:Pattern=\"Solid\"/><Alignment ss:Horizontal=\"Center\"/><Borders><Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#DDDDDD\"/></Borders></Style>");
            sb.AppendLine("<Style ss:ID=\"sInbound\"><Font ss:Size=\"10\" ss:Color=\"#2E7D32\"/><Alignment ss:Horizontal=\"Center\"/><Borders><Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#DDDDDD\"/></Borders></Style>");
            sb.AppendLine("<Style ss:ID=\"sOutbound\"><Font ss:Size=\"10\" ss:Color=\"#C62828\"/><Alignment ss:Horizontal=\"Center\"/><Borders><Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#DDDDDD\"/></Borders></Style>");
            sb.AppendLine("<Style ss:ID=\"sTotal\"><Font ss:Size=\"11\" ss:Bold=\"1\"/><Interior ss:Color=\"#E3F2FD\" ss:Pattern=\"Solid\"/><Alignment ss:Horizontal=\"Center\"/><Borders><Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\" ss:Color=\"#333333\"/></Borders></Style>");
            sb.AppendLine("<Style ss:ID=\"sTotalInbound\"><Font ss:Size=\"11\" ss:Bold=\"1\" ss:Color=\"#2E7D32\"/><Interior ss:Color=\"#E3F2FD\" ss:Pattern=\"Solid\"/><Alignment ss:Horizontal=\"Center\"/><Borders><Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\" ss:Color=\"#333333\"/></Borders></Style>");
            sb.AppendLine("<Style ss:ID=\"sTotalOutbound\"><Font ss:Size=\"11\" ss:Bold=\"1\" ss:Color=\"#C62828\"/><Interior ss:Color=\"#E3F2FD\" ss:Pattern=\"Solid\"/><Alignment ss:Horizontal=\"Center\"/><Borders><Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\" ss:Color=\"#333333\"/></Borders></Style>");
            sb.AppendLine("</Styles>");

            // 工作表
            sb.AppendLine("<Worksheet ss:Name=\"出入库报表\">");
            sb.AppendLine("<Table ss:DefaultColumnWidth=\"100\" ss:DefaultRowHeight=\"22\">");

            // 列宽
            sb.AppendLine("<Column ss:Width=\"100\"/>");
            sb.AppendLine("<Column ss:Width=\"120\"/>");
            sb.AppendLine("<Column ss:Width=\"120\"/>");
            sb.AppendLine("<Column ss:Width=\"120\"/>");

            // 标题行
            sb.AppendLine("<Row ss:Height=\"32\">");
            sb.AppendLine($"<Cell ss:StyleID=\"sTitle\" ss:MergeAcross=\"3\"><Data ss:Type=\"String\">出入库统计报表</Data></Cell>");
            sb.AppendLine("</Row>");

            // 副标题
            sb.AppendLine("<Row ss:Height=\"18\">");
            sb.AppendLine($"<Cell ss:StyleID=\"sSubtitle\" ss:MergeAcross=\"3\"><Data ss:Type=\"String\">统计维度：{filterLabel} | 导出时间：{reportTime} | 操作员：{userName}({roleName})</Data></Cell>");
            sb.AppendLine("</Row>");

            // 空行
            sb.AppendLine("<Row/>");

            // 表头
            sb.AppendLine("<Row ss:Height=\"26\">");
            sb.AppendLine("<Cell ss:StyleID=\"sHeader\"><Data ss:Type=\"String\">期间</Data></Cell>");
            sb.AppendLine("<Cell ss:StyleID=\"sHeader\"><Data ss:Type=\"String\">入库数量</Data></Cell>");
            sb.AppendLine("<Cell ss:StyleID=\"sHeader\"><Data ss:Type=\"String\">出库数量</Data></Cell>");
            sb.AppendLine("<Cell ss:StyleID=\"sHeader\"><Data ss:Type=\"String\">库存变化</Data></Cell>");
            sb.AppendLine("</Row>");

            // 数据行
            int totalInbound = 0, totalOutbound = 0, totalChange = 0;
            for (int i = 0; i < data.Count; i++)
            {
                var d = data[i];
                totalInbound += d.Inbound;
                totalOutbound += d.Outbound;
                totalChange += d.Change;

                string rowStyle = i % 2 == 0 ? "sData" : "sDataAlt";
                string changeStr = d.Change >= 0 ? $"+{d.Change}" : d.Change.ToString();

                sb.AppendLine("<Row>");
                sb.AppendLine($"<Cell ss:StyleID=\"{rowStyle}\"><Data ss:Type=\"String\">{d.Period}</Data></Cell>");
                sb.AppendLine($"<Cell ss:StyleID=\"sInbound\"><Data ss:Type=\"Number\">{d.Inbound}</Data></Cell>");
                sb.AppendLine($"<Cell ss:StyleID=\"sOutbound\"><Data ss:Type=\"Number\">{d.Outbound}</Data></Cell>");
                sb.AppendLine($"<Cell ss:StyleID=\"{rowStyle}\"><Data ss:Type=\"String\">{changeStr}</Data></Cell>");
                sb.AppendLine("</Row>");
            }

            // 汇总行
            string totalChangeStr = totalChange >= 0 ? $"+{totalChange}" : totalChange.ToString();
            sb.AppendLine("<Row ss:Height=\"26\">");
            sb.AppendLine("<Cell ss:StyleID=\"sTotal\"><Data ss:Type=\"String\">合计</Data></Cell>");
            sb.AppendLine($"<Cell ss:StyleID=\"sTotalInbound\"><Data ss:Type=\"Number\">{totalInbound}</Data></Cell>");
            sb.AppendLine($"<Cell ss:StyleID=\"sTotalOutbound\"><Data ss:Type=\"Number\">{totalOutbound}</Data></Cell>");
            sb.AppendLine($"<Cell ss:StyleID=\"sTotal\"><Data ss:Type=\"String\">{totalChangeStr}</Data></Cell>");
            sb.AppendLine("</Row>");

            sb.AppendLine("</Table>");
            sb.AppendLine("</Worksheet>");
            sb.AppendLine("</Workbook>");

            return sb.ToString();
        }

        private void BtnQuery_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private async void LoadData()
        {
            try
            {
                var data = await GetStatisticsDataAsync();
                DrawLineChart(data);
                DrawBarChart(data);
                LoadReportDataGrid(data);
            }
            catch (Exception ex)
            {
                MessageBox.Show("加载数据失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task<List<StatData>> GetStatisticsDataAsync()
        {
            var result = new List<StatData>();
            string sql = "";
            var parameters = new List<SqliteParameter>();

            switch (_currentFilter)
            {
                case DateFilterType.Year:
                    sql = @"
                        SELECT CAST(strftime('%Y', 入库时间) AS INTEGER) as Period, 
                               SUM(CASE WHEN 类型='入库' THEN 数量 ELSE 0 END) as Inbound,
                               SUM(CASE WHEN 类型='出库' THEN 数量 ELSE 0 END) as Outbound
                        FROM (
                            SELECT 入库时间, 数量, '入库' as 类型 FROM 入库
                            UNION ALL
                            SELECT 出库时间, 数量, '出库' as 类型 FROM 出库
                        ) t
                        WHERE CAST(strftime('%Y', 入库时间) AS INTEGER) BETWEEN @StartYear AND @EndYear
                        GROUP BY CAST(strftime('%Y', 入库时间) AS INTEGER)
                        ORDER BY Period";
                    parameters.Add(new SqliteParameter("@StartYear", _selectedYear - 9));
                    parameters.Add(new SqliteParameter("@EndYear", _selectedYear));
                    break;

                case DateFilterType.Month:
                    sql = @"
                        SELECT CAST(strftime('%m', 入库时间) AS INTEGER) as Period, 
                               SUM(CASE WHEN 类型='入库' THEN 数量 ELSE 0 END) as Inbound,
                               SUM(CASE WHEN 类型='出库' THEN 数量 ELSE 0 END) as Outbound
                        FROM (
                            SELECT 入库时间, 数量, '入库' as 类型 FROM 入库
                            UNION ALL
                            SELECT 出库时间, 数量, '出库' as 类型 FROM 出库
                        ) t
                        WHERE CAST(strftime('%Y', 入库时间) AS INTEGER) = @Year
                        GROUP BY CAST(strftime('%m', 入库时间) AS INTEGER)
                        ORDER BY Period";
                    parameters.Add(new SqliteParameter("@Year", _selectedYear));
                    break;

                case DateFilterType.Day:
                    sql = @"
                        SELECT CAST(strftime('%d', 入库时间) AS INTEGER) as Period, 
                               SUM(CASE WHEN 类型='入库' THEN 数量 ELSE 0 END) as Inbound,
                               SUM(CASE WHEN 类型='出库' THEN 数量 ELSE 0 END) as Outbound
                        FROM (
                            SELECT 入库时间, 数量, '入库' as 类型 FROM 入库
                            UNION ALL
                            SELECT 出库时间, 数量, '出库' as 类型 FROM 出库
                        ) t
                        WHERE CAST(strftime('%Y', 入库时间) AS INTEGER) = @Year AND CAST(strftime('%m', 入库时间) AS INTEGER) = @Month
                        GROUP BY CAST(strftime('%d', 入库时间) AS INTEGER)
                        ORDER BY Period";
                    parameters.Add(new SqliteParameter("@Year", _selectedYear));
                    parameters.Add(new SqliteParameter("@Month", _selectedMonth));
                    break;
            }

            var dataTable = await Task.Run(() => DbHelper.ExecuteQuery(sql, parameters.ToArray()));
            
            foreach (DataRow row in dataTable.Rows)
            {
                int period = Convert.ToInt32(row["Period"]);
                int inbound = row["Inbound"] != DBNull.Value ? Convert.ToInt32(row["Inbound"]) : 0;
                int outbound = row["Outbound"] != DBNull.Value ? Convert.ToInt32(row["Outbound"]) : 0;
                
                result.Add(new StatData
                {
                    Period = GetPeriodLabel(period),
                    PeriodValue = period,
                    Inbound = inbound,
                    Outbound = outbound,
                    Change = inbound - outbound
                });
            }

            return FillMissingPeriods(result);
        }

        private string GetPeriodLabel(int period)
        {
            switch (_currentFilter)
            {
                case DateFilterType.Year: return $"{period}年";
                case DateFilterType.Month: return $"{period}月";
                case DateFilterType.Day: return period.ToString();
                default: return period.ToString();
            }
        }

        private List<StatData> FillMissingPeriods(List<StatData> data)
        {
            var result = new List<StatData>();

            if (_currentFilter == DateFilterType.Year)
            {
                for (int y = _selectedYear - 9; y <= _selectedYear; y++)
                {
                    var existing = data.FirstOrDefault(d => d.PeriodValue == y);
                    result.Add(existing ?? new StatData { Period = $"{y}年", PeriodValue = y, Inbound = 0, Outbound = 0, Change = 0 });
                }
            }
            else if (_currentFilter == DateFilterType.Month)
            {
                for (int m = 1; m <= 12; m++)
                {
                    var existing = data.FirstOrDefault(d => d.PeriodValue == m);
                    result.Add(existing ?? new StatData { Period = $"{m}月", PeriodValue = m, Inbound = 0, Outbound = 0, Change = 0 });
                }
            }
            else if (_currentFilter == DateFilterType.Day)
            {
                int days = DateTime.DaysInMonth(_selectedYear, _selectedMonth);
                for (int day = 1; day <= days; day++)
                {
                    var existing = data.FirstOrDefault(x => x.PeriodValue == day);
                    result.Add(existing ?? new StatData { Period = day.ToString(), PeriodValue = day, Inbound = 0, Outbound = 0, Change = 0 });
                }
            }
            return result;
        }

        private void DrawLineChart(List<StatData> data)
        {
            LineChartCanvas.Children.Clear();

            double canvasWidth = LineChartCanvas.ActualWidth;
            double canvasHeight = LineChartCanvas.ActualHeight;
            if (canvasWidth == 0) canvasWidth = 400;
            if (canvasHeight == 0) canvasHeight = 250;

            double padding = 50;
            double rightPadding = 60;
            double chartWidth = canvasWidth - padding - rightPadding;
            double chartHeight = canvasHeight - padding * 2;

            if (data.Count == 0) return;

            int maxValue = data.Max(d => Math.Max(d.Inbound, d.Outbound));
            if (maxValue == 0) maxValue = 100;
            maxValue = (int)Math.Ceiling(maxValue * 1.2 / 10.0) * 10;

            double stepX = data.Count > 1 ? chartWidth / (data.Count - 1) : 0;

            for (int i = 0; i <= 5; i++)
            {
                double y = padding + chartHeight - (chartHeight / 5) * i;
                var gridLine = new Line
                {
                    X1 = padding,
                    Y1 = y,
                    X2 = canvasWidth - rightPadding,
                    Y2 = y,
                    Stroke = new SolidColorBrush(Color.FromRgb(220, 220, 220)),
                    StrokeThickness = 1
                };
                LineChartCanvas.Children.Add(gridLine);

                var label = new TextBlock
                {
                    Text = ((maxValue / 5) * i).ToString(),
                    FontSize = 10,
                    Foreground = new SolidColorBrush(Color.FromRgb(100, 100, 100))
                };
                Canvas.SetLeft(label, 5);
                Canvas.SetTop(label, y - 8);
                LineChartCanvas.Children.Add(label);
            }

            for (int i = 0; i < data.Count; i++)
            {
                double x = padding + (data.Count > 1 ? stepX * i : chartWidth / 2);
                var label = new TextBlock
                {
                    Text = data[i].Period,
                    FontSize = 10,
                    Foreground = new SolidColorBrush(Color.FromRgb(100, 100, 100))
                };
                double labelWidth = data[i].Period.Length * 6;
                Canvas.SetLeft(label, x - labelWidth / 2);
                Canvas.SetTop(label, canvasHeight - padding + 10);
                LineChartCanvas.Children.Add(label);
            }

            var inboundPoints = new PointCollection();
            for (int i = 0; i < data.Count; i++)
            {
                double x = padding + (data.Count > 1 ? stepX * i : chartWidth / 2);
                double y = padding + chartHeight - (data[i].Inbound / (double)maxValue) * chartHeight;
                inboundPoints.Add(new Point(x, y));

                var dot = new Ellipse { Width = 8, Height = 8, Fill = new SolidColorBrush(Color.FromRgb(76, 175, 80)) };
                Canvas.SetLeft(dot, x - 4);
                Canvas.SetTop(dot, y - 4);
                LineChartCanvas.Children.Add(dot);
            }
            var inboundLine = new Polyline { Points = inboundPoints, Stroke = new SolidColorBrush(Color.FromRgb(76, 175, 80)), StrokeThickness = 2 };
            LineChartCanvas.Children.Add(inboundLine);

            var outboundPoints = new PointCollection();
            for (int i = 0; i < data.Count; i++)
            {
                double x = padding + (data.Count > 1 ? stepX * i : chartWidth / 2);
                double y = padding + chartHeight - (data[i].Outbound / (double)maxValue) * chartHeight;
                outboundPoints.Add(new Point(x, y));

                var dot = new Ellipse { Width = 8, Height = 8, Fill = new SolidColorBrush(Color.FromRgb(33, 150, 243)) };
                Canvas.SetLeft(dot, x - 4);
                Canvas.SetTop(dot, y - 4);
                LineChartCanvas.Children.Add(dot);
            }
            var outboundLine = new Polyline { Points = outboundPoints, Stroke = new SolidColorBrush(Color.FromRgb(33, 150, 243)), StrokeThickness = 2 };
            LineChartCanvas.Children.Add(outboundLine);

            AddLegend(LineChartCanvas, padding);
        }

        private void DrawBarChart(List<StatData> data)
        {
            BarChartCanvas.Children.Clear();

            double canvasWidth = BarChartCanvas.ActualWidth;
            double canvasHeight = BarChartCanvas.ActualHeight;
            if (canvasWidth == 0) canvasWidth = 400;
            if (canvasHeight == 0) canvasHeight = 250;

            double padding = 50;
            double rightPadding = 60;
            double chartWidth = canvasWidth - padding - rightPadding;
            double chartHeight = canvasHeight - padding * 2;

            if (data.Count == 0) return;

            int maxValue = data.Max(d => Math.Max(d.Inbound, d.Outbound));
            if (maxValue == 0) maxValue = 100;
            maxValue = (int)Math.Ceiling(maxValue * 1.2 / 10.0) * 10;

            double groupWidth = chartWidth / data.Count;
            double barWidth = groupWidth * 0.35;
            double gap = groupWidth * 0.1;

            for (int i = 0; i <= 5; i++)
            {
                double y = padding + chartHeight - (chartHeight / 5) * i;
                var gridLine = new Line
                {
                    X1 = padding,
                    Y1 = y,
                    X2 = canvasWidth - rightPadding,
                    Y2 = y,
                    Stroke = new SolidColorBrush(Color.FromRgb(220, 220, 220)),
                    StrokeThickness = 1
                };
                BarChartCanvas.Children.Add(gridLine);

                var label = new TextBlock
                {
                    Text = ((maxValue / 5) * i).ToString(),
                    FontSize = 10,
                    Foreground = new SolidColorBrush(Color.FromRgb(100, 100, 100))
                };
                Canvas.SetLeft(label, 5);
                Canvas.SetTop(label, y - 8);
                BarChartCanvas.Children.Add(label);
            }

            for (int i = 0; i < data.Count; i++)
            {
                double groupX = padding + groupWidth * i;

                double inboundHeight = (data[i].Inbound / (double)maxValue) * chartHeight;
                var inboundBar = new Rectangle
                {
                    Width = barWidth,
                    Height = inboundHeight,
                    Fill = new SolidColorBrush(Color.FromRgb(76, 175, 80)),
                    RadiusX = 3,
                    RadiusY = 3
                };
                Canvas.SetLeft(inboundBar, groupX + gap);
                Canvas.SetTop(inboundBar, padding + chartHeight - inboundHeight);
                BarChartCanvas.Children.Add(inboundBar);

                double outboundHeight = (data[i].Outbound / (double)maxValue) * chartHeight;
                var outboundBar = new Rectangle
                {
                    Width = barWidth,
                    Height = outboundHeight,
                    Fill = new SolidColorBrush(Color.FromRgb(33, 150, 243)),
                    RadiusX = 3,
                    RadiusY = 3
                };
                Canvas.SetLeft(outboundBar, groupX + gap + barWidth + 5);
                Canvas.SetTop(outboundBar, padding + chartHeight - outboundHeight);
                BarChartCanvas.Children.Add(outboundBar);

                var label = new TextBlock
                {
                    Text = data[i].Period,
                    FontSize = 10,
                    Foreground = new SolidColorBrush(Color.FromRgb(100, 100, 100))
                };
                double labelWidth = data[i].Period.Length * 6;
                Canvas.SetLeft(label, groupX + groupWidth / 2 - labelWidth / 2);
                Canvas.SetTop(label, canvasHeight - padding + 10);
                BarChartCanvas.Children.Add(label);
            }

            AddLegend(BarChartCanvas, padding, true);
        }

        private void AddLegend(Canvas canvas, double padding, bool isBar = false)
        {
            var legendInbound = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 15, 0) };
            if (isBar)
                legendInbound.Children.Add(new Rectangle { Width = 12, Height = 12, Fill = new SolidColorBrush(Color.FromRgb(76, 175, 80)) });
            else
                legendInbound.Children.Add(new Ellipse { Width = 12, Height = 12, Fill = new SolidColorBrush(Color.FromRgb(76, 175, 80)) });
            legendInbound.Children.Add(new TextBlock { Text = " 入库", FontSize = 12, VerticalAlignment = VerticalAlignment.Center });
            Canvas.SetLeft(legendInbound, padding);
            Canvas.SetTop(legendInbound, 5);
            canvas.Children.Add(legendInbound);

            var legendOutbound = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 0) };
            if (isBar)
                legendOutbound.Children.Add(new Rectangle { Width = 12, Height = 12, Fill = new SolidColorBrush(Color.FromRgb(33, 150, 243)) });
            else
                legendOutbound.Children.Add(new Ellipse { Width = 12, Height = 12, Fill = new SolidColorBrush(Color.FromRgb(33, 150, 243)) });
            legendOutbound.Children.Add(new TextBlock { Text = " 出库", FontSize = 12, VerticalAlignment = VerticalAlignment.Center });
            Canvas.SetLeft(legendOutbound, padding + 80);
            Canvas.SetTop(legendOutbound, 5);
            canvas.Children.Add(legendOutbound);
        }

        private void LoadReportDataGrid(List<StatData> data)
        {
            var reportData = data.Select(d => new
            {
                Period = d.Period,
                Inbound = d.Inbound.ToString(),
                Outbound = d.Outbound.ToString(),
                Change = d.Change >= 0 ? "+" + d.Change : d.Change.ToString()
            }).ToList();

            ReportDataGrid.ItemsSource = reportData;
        }

        public class StatData
        {
            public string Period { get; set; }
            public int PeriodValue { get; set; }
            public int Inbound { get; set; }
            public int Outbound { get; set; }
            public int Change { get; set; }
        }
    }
}