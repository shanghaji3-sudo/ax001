using System.IO;
using Microsoft.Data.Sqlite;

namespace MES仓储管理系统
{
    public static class DatabaseInitializer
    {
        private static readonly string DbPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "仓储管理.db");
        private static readonly string ConnectionString = $"Data Source={DbPath}";

        public static string GetConnectionString() => ConnectionString;

        public static void Initialize()
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();

            CreateTables(connection);
            SeedSampleData(connection);
        }

        private static void CreateTables(SqliteConnection connection)
        {
            var cmd = connection.CreateCommand();

            cmd.CommandText = @"
                CREATE TABLE IF NOT EXISTS Users (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Username TEXT NOT NULL UNIQUE,
                    PasswordHash TEXT NOT NULL,
                    RealName TEXT NOT NULL,
                    Role INTEGER NOT NULL DEFAULT 4,
                    Phone TEXT,
                    Email TEXT,
                    IsActive INTEGER NOT NULL DEFAULT 1,
                    LastLoginTime TEXT,
                    CreatedTime TEXT NOT NULL DEFAULT (datetime('now','localtime')),
                    CreatedBy INTEGER
                );

                CREATE INDEX IF NOT EXISTS IX_Users_Username ON Users(Username);
                CREATE INDEX IF NOT EXISTS IX_Users_IsActive ON Users(IsActive);
            ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = @"
                CREATE TABLE IF NOT EXISTS LoginLogs (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    UserId INTEGER NOT NULL,
                    Username TEXT NOT NULL,
                    LoginTime TEXT NOT NULL DEFAULT (datetime('now','localtime')),
                    IsSuccess INTEGER NOT NULL,
                    IpAddress TEXT,
                    UserAgent TEXT
                );

                CREATE INDEX IF NOT EXISTS IX_LoginLogs_UserId ON LoginLogs(UserId);
                CREATE INDEX IF NOT EXISTS IX_LoginLogs_LoginTime ON LoginLogs(LoginTime);
            ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = @"
                CREATE TABLE IF NOT EXISTS 入库 (
                    入库单号 TEXT PRIMARY KEY,
                    物料名称 TEXT NOT NULL,
                    物料编码 TEXT NOT NULL,
                    数量 INTEGER NOT NULL,
                    仓库 TEXT NOT NULL,
                    入库时间 TEXT NOT NULL,
                    操作人 TEXT NOT NULL,
                    状态 TEXT NOT NULL
                );
            ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = @"
                CREATE TABLE IF NOT EXISTS 出库 (
                    出库单号 TEXT PRIMARY KEY,
                    物料名称 TEXT NOT NULL,
                    物料编码 TEXT NOT NULL,
                    数量 INTEGER NOT NULL,
                    仓库 TEXT NOT NULL,
                    出库时间 TEXT NOT NULL,
                    操作人 TEXT NOT NULL,
                    状态 TEXT NOT NULL
                );
            ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = @"
                CREATE TABLE IF NOT EXISTS 库存 (
                    物料编码 TEXT NOT NULL,
                    物料名称 TEXT NOT NULL,
                    规格型号 TEXT NOT NULL,
                    仓库 TEXT NOT NULL,
                    库位 TEXT NOT NULL,
                    库存数量 INTEGER NOT NULL,
                    安全库存 INTEGER NOT NULL,
                    更新时间 TEXT NOT NULL,
                    PRIMARY KEY (物料编码, 仓库, 库位)
                );
            ";
            cmd.ExecuteNonQuery();
        }

        private static void SeedSampleData(SqliteConnection connection)
        {
            var cmd = connection.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM 入库";
            var count = (long)(cmd.ExecuteScalar() ?? 0);
            if (count > 0) return;

            using var transaction = connection.BeginTransaction();

            // 入库示例数据
            var inboundData = new (string No, string Name, string Code, int Qty, string Wh, string Time, string Operator, string Status)[]
            {
                ("RK202401001", "钢材", "WL001", 100, "一号仓库", "2024-01-15 08:30:00", "张三", "已入库"),
                ("RK202401002", "水泥", "WL002", 500, "二号仓库", "2024-01-16 09:15:00", "李四", "已入库"),
                ("RK202401003", "砂石", "WL003", 200, "一号仓库", "2024-01-18 10:00:00", "王五", "已入库"),
                ("RK202402001", "钢材", "WL001", 150, "三号仓库", "2024-02-10 08:45:00", "张三", "已入库"),
                ("RK202402002", "水泥", "WL002", 300, "一号仓库", "2024-02-12 14:20:00", "李四", "已入库"),
                ("RK202402003", "铝材", "WL004", 80, "二号仓库", "2024-02-20 11:30:00", "赵六", "已入库"),
                ("RK202403001", "钢材", "WL001", 200, "一号仓库", "2024-03-05 09:00:00", "张三", "已入库"),
                ("RK202403002", "水泥", "WL002", 400, "四号仓库", "2024-03-08 13:30:00", "李四", "已入库"),
                ("RK202403003", "砂石", "WL003", 250, "三号仓库", "2024-03-15 15:45:00", "王五", "已入库"),
                ("RK202404001", "钢材", "WL001", 120, "二号仓库", "2024-04-10 08:30:00", "张三", "已入库"),
                ("RK202404002", "铝材", "WL004", 100, "一号仓库", "2024-04-12 10:15:00", "赵六", "已入库"),
                ("RK202405001", "钢材", "WL001", 180, "三号仓库", "2024-05-08 09:30:00", "张三", "已入库"),
                ("RK202405002", "水泥", "WL002", 350, "一号仓库", "2024-05-15 14:00:00", "李四", "已入库"),
                ("RK202406001", "砂石", "WL003", 180, "四号仓库", "2024-06-10 11:00:00", "王五", "已入库"),
                ("RK202406002", "钢材", "WL001", 160, "二号仓库", "2024-06-18 16:30:00", "张三", "已入库"),
                ("RK202407001", "水泥", "WL002", 450, "一号仓库", "2024-07-05 08:45:00", "李四", "已入库"),
                ("RK202407002", "铝材", "WL004", 120, "三号仓库", "2024-07-12 13:15:00", "赵六", "已入库"),
                ("RK202408001", "钢材", "WL001", 220, "一号仓库", "2024-08-08 09:00:00", "张三", "已入库"),
                ("RK202408002", "砂石", "WL003", 300, "二号仓库", "2024-08-15 10:30:00", "王五", "已入库"),
                ("RK202409001", "水泥", "WL002", 380, "四号仓库", "2024-09-10 14:20:00", "李四", "已入库"),
            };

            using (var insertCmd = connection.CreateCommand())
            {
                insertCmd.CommandText = @"INSERT INTO 入库 (入库单号, 物料名称, 物料编码, 数量, 仓库, 入库时间, 操作人, 状态)
                                         VALUES (@No, @Name, @Code, @Qty, @Wh, @Time, @Operator, @Status)";
                foreach (var d in inboundData)
                {
                    insertCmd.Parameters.Clear();
                    insertCmd.Parameters.AddWithValue("@No", d.No);
                    insertCmd.Parameters.AddWithValue("@Name", d.Name);
                    insertCmd.Parameters.AddWithValue("@Code", d.Code);
                    insertCmd.Parameters.AddWithValue("@Qty", d.Qty);
                    insertCmd.Parameters.AddWithValue("@Wh", d.Wh);
                    insertCmd.Parameters.AddWithValue("@Time", d.Time);
                    insertCmd.Parameters.AddWithValue("@Operator", d.Operator);
                    insertCmd.Parameters.AddWithValue("@Status", d.Status);
                    insertCmd.ExecuteNonQuery();
                }
            }

            // 出库示例数据
            var outboundData = new (string No, string Name, string Code, int Qty, string Wh, string Time, string Operator, string Status)[]
            {
                ("CK202401001", "钢材", "WL001", 50, "一号仓库", "2024-01-20 10:00:00", "张三", "已出库"),
                ("CK202401002", "水泥", "WL002", 100, "二号仓库", "2024-01-22 14:30:00", "李四", "已出库"),
                ("CK202402001", "钢材", "WL001", 80, "一号仓库", "2024-02-15 09:15:00", "张三", "已出库"),
                ("CK202402002", "水泥", "WL002", 150, "二号仓库", "2024-02-18 11:00:00", "李四", "已出库"),
                ("CK202402003", "铝材", "WL004", 30, "三号仓库", "2024-02-25 16:20:00", "赵六", "已出库"),
                ("CK202403001", "钢材", "WL001", 60, "三号仓库", "2024-03-10 08:30:00", "张三", "已出库"),
                ("CK202403002", "砂石", "WL003", 80, "一号仓库", "2024-03-12 13:45:00", "王五", "已出库"),
                ("CK202404001", "水泥", "WL002", 120, "四号仓库", "2024-04-08 10:00:00", "李四", "已出库"),
                ("CK202404002", "钢材", "WL001", 70, "二号仓库", "2024-04-15 15:30:00", "张三", "已出库"),
                ("CK202405001", "砂石", "WL003", 100, "三号仓库", "2024-05-10 09:45:00", "王五", "已出库"),
                ("CK202405002", "水泥", "WL002", 180, "一号仓库", "2024-05-20 11:15:00", "李四", "已出库"),
                ("CK202406001", "钢材", "WL001", 90, "四号仓库", "2024-06-12 14:00:00", "张三", "已出库"),
                ("CK202406002", "铝材", "WL004", 50, "二号仓库", "2024-06-18 16:45:00", "赵六", "已出库"),
                ("CK202407001", "水泥", "WL002", 200, "一号仓库", "2024-07-08 08:30:00", "李四", "已出库"),
                ("CK202407002", "钢材", "WL001", 100, "三号仓库", "2024-07-15 10:30:00", "张三", "已出库"),
                ("CK202408001", "砂石", "WL003", 120, "二号仓库", "2024-08-10 13:00:00", "王五", "已出库"),
                ("CK202408002", "水泥", "WL002", 160, "四号仓库", "2024-08-20 15:45:00", "李四", "已出库"),
                ("CK202409001", "钢材", "WL001", 110, "一号仓库", "2024-09-05 09:30:00", "张三", "已出库"),
            };

            using (var insertCmd = connection.CreateCommand())
            {
                insertCmd.CommandText = @"INSERT INTO 出库 (出库单号, 物料名称, 物料编码, 数量, 仓库, 出库时间, 操作人, 状态)
                                         VALUES (@No, @Name, @Code, @Qty, @Wh, @Time, @Operator, @Status)";
                foreach (var d in outboundData)
                {
                    insertCmd.Parameters.Clear();
                    insertCmd.Parameters.AddWithValue("@No", d.No);
                    insertCmd.Parameters.AddWithValue("@Name", d.Name);
                    insertCmd.Parameters.AddWithValue("@Code", d.Code);
                    insertCmd.Parameters.AddWithValue("@Qty", d.Qty);
                    insertCmd.Parameters.AddWithValue("@Wh", d.Wh);
                    insertCmd.Parameters.AddWithValue("@Time", d.Time);
                    insertCmd.Parameters.AddWithValue("@Operator", d.Operator);
                    insertCmd.Parameters.AddWithValue("@Status", d.Status);
                    insertCmd.ExecuteNonQuery();
                }
            }

            // 库存示例数据
            var inventoryData = new (string Code, string Name, string Spec, string Wh, string Loc, int Qty, int Safety)[]
            {
                ("WL001", "钢材", "Q235B-10mm", "一号仓库", "A01", 500, 100),
                ("WL001", "钢材", "Q235B-10mm", "二号仓库", "B02", 300, 100),
                ("WL001", "钢材", "Q235B-10mm", "三号仓库", "C01", 200, 100),
                ("WL002", "水泥", "P.O 42.5", "一号仓库", "A02", 1200, 200),
                ("WL002", "水泥", "P.O 42.5", "二号仓库", "B01", 800, 200),
                ("WL002", "水泥", "P.O 42.5", "四号仓库", "D03", 600, 200),
                ("WL003", "砂石", "中砂", "一号仓库", "A03", 500, 150),
                ("WL003", "砂石", "中砂", "三号仓库", "C02", 400, 150),
                ("WL003", "砂石", "中砂", "四号仓库", "D01", 300, 150),
                ("WL004", "铝材", "6061-T6-5mm", "一号仓库", "A04", 200, 50),
                ("WL004", "铝材", "6061-T6-5mm", "二号仓库", "B03", 150, 50),
                ("WL004", "铝材", "6061-T6-5mm", "三号仓库", "C03", 100, 50),
            };

            using (var insertCmd = connection.CreateCommand())
            {
                insertCmd.CommandText = @"INSERT INTO 库存 (物料编码, 物料名称, 规格型号, 仓库, 库位, 库存数量, 安全库存, 更新时间)
                                         VALUES (@Code, @Name, @Spec, @Wh, @Loc, @Qty, @Safety, datetime('now','localtime'))";
                foreach (var d in inventoryData)
                {
                    insertCmd.Parameters.Clear();
                    insertCmd.Parameters.AddWithValue("@Code", d.Code);
                    insertCmd.Parameters.AddWithValue("@Name", d.Name);
                    insertCmd.Parameters.AddWithValue("@Spec", d.Spec);
                    insertCmd.Parameters.AddWithValue("@Wh", d.Wh);
                    insertCmd.Parameters.AddWithValue("@Loc", d.Loc);
                    insertCmd.Parameters.AddWithValue("@Qty", d.Qty);
                    insertCmd.Parameters.AddWithValue("@Safety", d.Safety);
                    insertCmd.ExecuteNonQuery();
                }
            }

            // 默认用户
            string defaultHash = MES仓储管理系统.AuthService.HashPassword("123456");
            using (var insertCmd = connection.CreateCommand())
            {
                insertCmd.CommandText = @"INSERT OR IGNORE INTO Users (Username, PasswordHash, RealName, Role, Phone, Email, IsActive, CreatedTime, CreatedBy)
                                         VALUES (@Username, @Hash, @RealName, @Role, @Phone, @Email, 1, datetime('now','localtime'), 0)";
                var users = new[]
                {
                    ("admin", "系统管理员", 1, "13800138000", "admin@mes.com"),
                    ("manager", "仓库主管", 2, "13800138001", "manager@mes.com"),
                    ("staff", "仓库员", 3, "13800138002", "staff@mes.com"),
                    ("viewer", "查看员", 4, "13800138003", "viewer@mes.com"),
                };
                foreach (var (username, realName, role, phone, email) in users)
                {
                    insertCmd.Parameters.Clear();
                    insertCmd.Parameters.AddWithValue("@Username", username);
                    insertCmd.Parameters.AddWithValue("@Hash", defaultHash);
                    insertCmd.Parameters.AddWithValue("@RealName", realName);
                    insertCmd.Parameters.AddWithValue("@Role", role);
                    insertCmd.Parameters.AddWithValue("@Phone", phone);
                    insertCmd.Parameters.AddWithValue("@Email", email);
                    insertCmd.ExecuteNonQuery();
                }
            }

            transaction.Commit();
        }
    }
}
