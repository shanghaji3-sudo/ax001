﻿using System.IO;
using System.Windows;
using System.Windows.Controls;
using MES仓储管理系统.Models;

namespace MES仓储管理系统
{
    public partial class 系统设置 : UserControl
    {
        public 系统设置()
        {
            InitializeComponent();
        }

        private async void BtnTestConnection_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool ok = await Task.Run(() => DbHelper.TestConnection());
                if (ok)
                {
                    string dbPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "仓储管理.db");
                    MessageBox.Show($"数据库连接成功！\n数据库文件：{dbPath}", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("数据库连接失败！", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("连接失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void BtnChangePwd_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(TxtOldPwd.Password))
            {
                MessageBox.Show("请输入原密码", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (string.IsNullOrEmpty(TxtNewPwd.Password))
            {
                MessageBox.Show("请输入新密码", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (TxtNewPwd.Password != TxtConfirmPwd.Password)
            {
                MessageBox.Show("两次输入的新密码不一致", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (TxtNewPwd.Password.Length < 6)
            {
                MessageBox.Show("新密码长度至少6位", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (TxtOldPwd.Password == TxtNewPwd.Password)
            {
                MessageBox.Show("新密码不能与原密码相同", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var user = CurrentUser.User;
            if (user == null)
            {
                MessageBox.Show("用户未登录", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                bool success = await Task.Run(() => AuthService.ChangePassword(user.Id, TxtOldPwd.Password, TxtNewPwd.Password));
                if (!success)
                {
                    MessageBox.Show("原密码错误，请重新输入", "修改失败", MessageBoxButton.OK, MessageBoxImage.Warning);
                    TxtOldPwd.Password = "";
                    TxtOldPwd.Focus();
                    return;
                }

                MessageBox.Show("密码修改成功，即将退出登录", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                AutoLogout();
            }
            catch (Exception ex)
            {
                MessageBox.Show("密码修改失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AutoLogout()
        {
            CurrentUser.Logout();
            var loginWindow = new LoginWindow();
            loginWindow.Show();
            Window.GetWindow(this)?.Close();
        }
    }
}
