using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using MES仓储管理系统.Models;

namespace MES仓储管理系统
{
    public partial class 首页 : UserControl
    {
        public 首页()
        {
            InitializeComponent();
            ApplyPermissions();
            UpdateUserInfo();
            UpdateSysInfo();
        }

        private void ApplyPermissions()
        {
            var user = CurrentUser.User;
            if (user == null) return;

            // 根据权限控制卡片可见性
            CardInbound.Visibility = user.HasPermission(Permission.InboundView) ? Visibility.Visible : Visibility.Collapsed;
            CardOutbound.Visibility = user.HasPermission(Permission.OutboundView) ? Visibility.Visible : Visibility.Collapsed;
            CardInventory.Visibility = user.HasPermission(Permission.InventoryView) ? Visibility.Visible : Visibility.Collapsed;
            CardReport.Visibility = user.HasPermission(Permission.ReportView) ? Visibility.Visible : Visibility.Collapsed;
            CardSettings.Visibility = (user.Role == UserRole.Admin || user.Role == UserRole.WarehouseManager) ? Visibility.Visible : Visibility.Collapsed;
            CardUserManage.Visibility = user.Role == UserRole.Admin ? Visibility.Visible : Visibility.Collapsed;

            // 根据权限更新卡片描述文字（显示操作能力）
            UpdateCardDescriptions(user);
        }

        private void UpdateCardDescriptions(User user)
        {
            // 入库管理描述
            if (CardDesc != null)
            {
                if (user.HasPermission(Permission.InboundCreate))
                    CardDesc.Text = "新增 / 查看 入库记录";
                else
                    CardDesc.Text = "查看入库记录";
            }

            // 出库管理描述
            if (CardDesc2 != null)
            {
                if (user.HasPermission(Permission.OutboundCreate))
                    CardDesc2.Text = "新增 / 查看 出库记录";
                else
                    CardDesc2.Text = "查看出库记录";
            }

            // 库存管理描述
            if (CardDesc3 != null)
            {
                if (user.HasPermission(Permission.InventoryCreate))
                    CardDesc3.Text = "新增 / 编辑 / 盘点库存";
                else
                    CardDesc3.Text = "实时库存查询";
            }
        }

        private void UpdateUserInfo()
        {
            var user = CurrentUser.User;
            if (user == null) return;

            string roleName = user.Role switch
            {
                UserRole.Admin => "系统管理员",
                UserRole.WarehouseManager => "仓库主管",
                UserRole.WarehouseStaff => "仓库员",
                UserRole.Viewer => "查看员",
                _ => "未知角色"
            };

            // 设置欢迎标题
            TblWelcome.Text = $"欢迎回来，{user.RealName}";

            // 设置角色描述
            string roleDesc = user.Role switch
            {
                UserRole.Admin => "您拥有系统所有权限，可管理用户、配置系统参数及全部业务模块。",
                UserRole.WarehouseManager => "您可管理入库/出库/库存操作，查看报表统计与系统设置。",
                UserRole.WarehouseStaff => "您可执行入库/出库操作，查看库存信息。",
                UserRole.Viewer => "您拥有只读查看权限，可浏览各模块数据。",
                _ => ""
            };
            TblRoleDesc.Text = roleDesc;

            // 显示角色徽章
            RoleBadge.Visibility = Visibility.Visible;
            string badgeColor = user.Role switch
            {
                UserRole.Admin => "#FF3366",
                UserRole.WarehouseManager => "#FFAA00",
                UserRole.WarehouseStaff => "#00FF88",
                UserRole.Viewer => "#00D4FF",
                _ => "#7A8BA0"
            };
            var badgeBrush = (SolidColorBrush)new BrushConverter().ConvertFromString(badgeColor);
            RoleBadge.Background = new SolidColorBrush(badgeBrush.Color) { Opacity = 0.15 };
            RoleBadge.BorderBrush = new SolidColorBrush(badgeBrush.Color) { Opacity = 0.4 };
            TblRoleBadge.Text = roleName;
            TblRoleBadge.Foreground = badgeBrush;
        }

        private void UpdateSysInfo()
        {
            var user = CurrentUser.User;
            if (user != null)
            {
                TblSysInfo.Text = $"USER: {user.RealName} | ROLE: {user.Role} | TIME: {DateTime.Now:yyyy-MM-dd HH:mm}";
            }
        }

        private void NavigateTo(UserControl page)
        {
            var parent = VisualTreeHelper.GetParent(this);
            while (parent != null && !(parent is Border))
            {
                parent = VisualTreeHelper.GetParent(parent);
            }
            if (parent is Border border)
            {
                border.Child = page;
            }
        }

        private void InboundCard_Click(object sender, MouseButtonEventArgs e)
        {
            if (!CurrentUser.HasPermission(Permission.InboundView))
            {
                MessageBox.Show("您没有权限访问入库管理", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            NavigateTo(new 入库管理());
        }

        private void OutboundCard_Click(object sender, MouseButtonEventArgs e)
        {
            if (!CurrentUser.HasPermission(Permission.OutboundView))
            {
                MessageBox.Show("您没有权限访问出库管理", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            NavigateTo(new 出库管理());
        }

        private void InventoryCard_Click(object sender, MouseButtonEventArgs e)
        {
            if (!CurrentUser.HasPermission(Permission.InventoryView))
            {
                MessageBox.Show("您没有权限访问库存管理", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            NavigateTo(new 库存管理());
        }

        private void ReportCard_Click(object sender, MouseButtonEventArgs e)
        {
            if (!CurrentUser.HasPermission(Permission.ReportView))
            {
                MessageBox.Show("您没有权限访问报表统计", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            NavigateTo(new 报表统计());
        }

        private void SettingsCard_Click(object sender, MouseButtonEventArgs e)
        {
            if (!(CurrentUser.IsAdmin || CurrentUser.User?.Role == UserRole.WarehouseManager))
            {
                MessageBox.Show("您没有权限访问系统设置", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            NavigateTo(new 系统设置());
        }

        private void UserManageCard_Click(object sender, MouseButtonEventArgs e)
        {
            if (!CurrentUser.IsAdmin)
            {
                MessageBox.Show("您没有权限访问用户管理", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            NavigateTo(new 用户管理());
        }
    }
}
