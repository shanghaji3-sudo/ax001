﻿using System.Windows;
using System.Windows.Threading;

namespace MES仓储管理系统
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            DispatcherUnhandledException += App_DispatcherUnhandledException;

            try
            {
                DatabaseInitializer.Initialize();
            }
            catch (Exception ex)
            {
                MessageBox.Show("数据库初始化失败：" + ex.Message + "\n\n" + (ex.InnerException?.Message ?? ""),
                    "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                Shutdown();
                return;
            }

            var loginWindow = new LoginWindow();
            loginWindow.Show();
        }

        private void App_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            MessageBox.Show("程序发生未处理异常：" + e.Exception.Message + "\n\n" + (e.Exception.InnerException?.Message ?? "") + "\n\n" + e.Exception.StackTrace,
                "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            e.Handled = true;
        }
    }
}
