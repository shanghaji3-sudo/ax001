using System;

namespace MES仓储管理系统.Models
{
    public enum UserRole
    {
        Admin = 1,        // 管理员 - 所有权限
        WarehouseManager = 2,  // 仓库主管 - 入库/出库/库存/报表
        WarehouseStaff = 3,    // 仓库员 - 入库/出库/库存查看
        Viewer = 4            // 查看员 - 只读查看
    }

    public enum Permission
    {
        // 入库权限
        InboundView = 1,
        InboundCreate = 2,
        InboundEdit = 3,
        InboundDelete = 4,

        // 出库权限
        OutboundView = 10,
        OutboundCreate = 11,
        OutboundEdit = 12,
        OutboundDelete = 13,

        // 库存权限
        InventoryView = 20,
        InventoryCreate = 21,
        InventoryEdit = 22,
        InventoryDelete = 23,
        InventoryCheck = 24,  // 盘点

        // 报表权限
        ReportView = 30,
        ReportExport = 31,

        // 系统设置权限
        SettingsView = 40,
        SettingsEdit = 41,
        UserManage = 42
    }

    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; } = "";
        public string PasswordHash { get; set; } = "";
        public string RealName { get; set; } = "";
        public UserRole Role { get; set; } = UserRole.Viewer;
        public string Phone { get; set; } = "";
        public string Email { get; set; } = "";
        public bool IsActive { get; set; } = true;
        public DateTime LastLoginTime { get; set; }
        public DateTime CreatedTime { get; set; } = DateTime.Now;
        public int CreatedBy { get; set; }

        // 权限缓存
        private HashSet<Permission>? _permissions;

        public HashSet<Permission> GetPermissions()
        {
            if (_permissions != null) return _permissions;

            _permissions = Role switch
            {
                UserRole.Admin => Enum.GetValues(typeof(Permission)).Cast<Permission>().ToHashSet(),
                UserRole.WarehouseManager => new HashSet<Permission>
                {
                    Permission.InboundView, Permission.InboundCreate, Permission.InboundEdit,
                    Permission.OutboundView, Permission.OutboundCreate, Permission.OutboundEdit,
                    Permission.InventoryView, Permission.InventoryCreate, Permission.InventoryEdit, Permission.InventoryCheck,
                    Permission.ReportView, Permission.ReportExport
                },
                UserRole.WarehouseStaff => new HashSet<Permission>
                {
                    Permission.InboundView, Permission.InboundCreate,
                    Permission.OutboundView, Permission.OutboundCreate,
                    Permission.InventoryView
                },
                UserRole.Viewer => new HashSet<Permission>
                {
                    Permission.InboundView,
                    Permission.OutboundView,
                    Permission.InventoryView,
                    Permission.ReportView
                },
                _ => new HashSet<Permission>()
            };
            return _permissions;
        }

        public bool HasPermission(Permission perm)
        {
            return GetPermissions().Contains(perm);
        }

        public void ClearPermissionCache()
        {
            _permissions = null;
        }
    }

    // 当前登录用户上下文
    public static class CurrentUser
    {
        private static User? _user;

        public static User? User => _user;

        public static bool IsLoggedIn => _user != null;

        public static void Login(User user)
        {
            _user = user;
        }

        public static void Logout()
        {
            _user = null;
        }

        public static bool HasPermission(Permission perm)
        {
            return _user?.HasPermission(perm) ?? false;
        }

        public static bool IsAdmin => _user?.Role == UserRole.Admin;
    }
}