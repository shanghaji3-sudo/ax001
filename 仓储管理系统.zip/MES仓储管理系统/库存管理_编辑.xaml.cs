using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace MES仓储管理系统
{
    public partial class 库存管理_编辑 : Window
    {
        public bool IsConfirmed { get; private set; }
        public string MaterialCode => TxtMaterialCode.Text.Trim();
        public string MaterialName => TxtMaterialName.Text.Trim();
        public string Spec => TxtSpec.Text.Trim();
        public string Warehouse => (CmbWarehouse.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";
        public string Location => TxtLocation.Text.Trim();
        public string Quantity => TxtQuantity.Text.Trim();
        public string SafetyStock => TxtSafetyStock.Text.Trim();
        public string UpdateTime => DpUpdateTime.SelectedDate?.ToString("yyyy-MM-dd") ?? "";

        public 库存管理_编辑()
        {
            InitializeComponent();
            IsConfirmed = false;
        }

        public void LoadData(DataRowView row)
        {
            TxtMaterialCode.Text = row["物料编码"]?.ToString() ?? "";
            TxtMaterialName.Text = row["物料名称"]?.ToString() ?? "";
            TxtSpec.Text = row["规格型号"]?.ToString() ?? "";
            CmbWarehouse.Text = row["仓库"]?.ToString() ?? "";
            TxtLocation.Text = row["库位"]?.ToString() ?? "";
            TxtQuantity.Text = row["库存数量"]?.ToString() ?? "";
            TxtSafetyStock.Text = row["安全库存"]?.ToString() ?? "";
            if (DateTime.TryParse(row["更新时间"]?.ToString(), out var dt))
                DpUpdateTime.SelectedDate = dt;
        }

        private void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(MaterialName))
            {
                MessageBox.Show("物料名称不能为空", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtMaterialName.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(Spec))
            {
                MessageBox.Show("规格型号不能为空", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtSpec.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(Warehouse))
            {
                MessageBox.Show("请选择仓库", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                CmbWarehouse.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(Location))
            {
                MessageBox.Show("库位不能为空", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtLocation.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(Quantity))
            {
                MessageBox.Show("库存数量不能为空", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtQuantity.Focus();
                return;
            }
            if (!int.TryParse(Quantity, out _))
            {
                MessageBox.Show("库存数量必须为整数", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtQuantity.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(SafetyStock))
            {
                MessageBox.Show("安全库存不能为空", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtSafetyStock.Focus();
                return;
            }
            if (!int.TryParse(SafetyStock, out _))
            {
                MessageBox.Show("安全库存必须为整数", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtSafetyStock.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(UpdateTime))
            {
                MessageBox.Show("更新时间不能为空", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                DpUpdateTime.Focus();
                return;
            }

            IsConfirmed = true;
            DialogResult = true;
            Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            IsConfirmed = false;
            DialogResult = false;
            Close();
        }
    }
}