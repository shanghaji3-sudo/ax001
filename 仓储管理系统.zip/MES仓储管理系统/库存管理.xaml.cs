using System.Data;
using Microsoft.Data.Sqlite;
using System.Windows;
using System.Windows.Controls;
using MES仓储管理系统.Models;

namespace MES仓储管理系统
{
    public partial class 库存管理 : UserControl
    {
        private CancellationTokenSource? _cts;

        public 库存管理()
        {
            InitializeComponent();
            ApplyPermissions();
            Loaded += InventoryManagement_Loaded;
        }

        private void ApplyPermissions()
        {
            var user = CurrentUser.User;
            if (user == null) return;
            BtnAddInventory.Visibility = user.HasPermission(Permission.InventoryCreate) ? Visibility.Visible : Visibility.Collapsed;
            BtnEditInventory.Visibility = user.HasPermission(Permission.InventoryEdit) ? Visibility.Visible : Visibility.Collapsed;
            BtnDeleteInventory.Visibility = user.HasPermission(Permission.InventoryDelete) ? Visibility.Visible : Visibility.Collapsed;
        }

        private void InventoryManagement_Loaded(object sender, RoutedEventArgs e) => LoadDataAsync();

        private async void LoadDataAsync()
        {
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            LoadingPanel.Visibility = Visibility.Visible;
            InventoryDataGrid.Visibility = Visibility.Collapsed;
            try
            {
                var dataTable = await Task.Run(() => DbHelper.ExecuteQuery("SELECT * FROM 库存"), token);
                if (!token.IsCancellationRequested)
                {
                    InventoryDataGrid.ItemsSource = dataTable.DefaultView;
                    LoadingPanel.Visibility = Visibility.Collapsed;
                    InventoryDataGrid.Visibility = Visibility.Visible;
                }
            }
            catch (Exception ex)
            {
                if (!token.IsCancellationRequested)
                {
                    MessageBox.Show("数据库连接失败：" + ex.Message, "连接失败", MessageBoxButton.OK, MessageBoxImage.Error);
                    LoadingPanel.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e) => LoadDataAsync();

        private void BtnAddInventory_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new 库存管理_新增库存 { Owner = Window.GetWindow(this) };
            if (dialog.ShowDialog() == true) SaveInventoryToDatabase(dialog);
        }

        private void BtnEditInventory_Click(object sender, RoutedEventArgs e)
        {
            if (InventoryDataGrid.SelectedItem is not DataRowView selectedRow)
            {
                MessageBox.Show("请先选择要编辑的行", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var dialog = new 库存管理_编辑 { Owner = Window.GetWindow(this) };
            dialog.LoadData(selectedRow);
            if (dialog.ShowDialog() == true) UpdateInventoryToDatabase(dialog, selectedRow["物料编码"]?.ToString() ?? "");
        }

        private async void SaveInventoryToDatabase(库存管理_新增库存 dialog)
        {
            try
            {
                var sql = @"INSERT INTO 库存 (物料编码, 物料名称, 规格型号, 仓库, 库位, 库存数量, 安全库存, 更新时间)
                            VALUES (@MaterialCode, @MaterialName, @Spec, @Warehouse, @Location, @Quantity, @SafetyStock, datetime('now','localtime'))";
                var parameters = new[]
                {
                    new SqliteParameter("@MaterialCode", dialog.MaterialCode), new SqliteParameter("@MaterialName", dialog.MaterialName),
                    new SqliteParameter("@Spec", dialog.Spec), new SqliteParameter("@Warehouse", dialog.Warehouse),
                    new SqliteParameter("@Location", dialog.Location), new SqliteParameter("@Quantity", int.Parse(dialog.Quantity)),
                    new SqliteParameter("@SafetyStock", int.Parse(dialog.SafetyStock))
                };
                await Task.Run(() => DbHelper.ExecuteNonQuery(sql, parameters));
                MessageBox.Show("库存记录保存成功！", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadDataAsync();
            }
            catch (Exception ex) { MessageBox.Show("保存失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private async void UpdateInventoryToDatabase(库存管理_编辑 dialog, string materialCode)
        {
            try
            {
                var sql = @"UPDATE 库存 SET 物料名称=@MaterialName, 规格型号=@Spec, 仓库=@Warehouse, 库位=@Location,
                            库存数量=@Quantity, 安全库存=@SafetyStock, 更新时间=datetime('now','localtime') WHERE 物料编码=@MaterialCode";
                var parameters = new[]
                {
                    new SqliteParameter("@MaterialCode", materialCode), new SqliteParameter("@MaterialName", dialog.MaterialName),
                    new SqliteParameter("@Spec", dialog.Spec), new SqliteParameter("@Warehouse", dialog.Warehouse),
                    new SqliteParameter("@Location", dialog.Location), new SqliteParameter("@Quantity", int.Parse(dialog.Quantity)),
                    new SqliteParameter("@SafetyStock", int.Parse(dialog.SafetyStock))
                };
                await Task.Run(() => DbHelper.ExecuteNonQuery(sql, parameters));
                MessageBox.Show("库存记录更新成功！", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadDataAsync();
            }
            catch (Exception ex) { MessageBox.Show("更新失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void BtnDeleteInventory_Click(object sender, RoutedEventArgs e)
        {
            if (InventoryDataGrid.SelectedItem is not DataRowView selectedRow)
            {
                MessageBox.Show("请先选择要删除的行", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var materialCode = selectedRow["物料编码"]?.ToString() ?? "";
            var materialName = selectedRow["物料名称"]?.ToString() ?? "";
            if (MessageBox.Show($"确定要删除物料编码为 [{materialCode}]、物料名称为 [{materialName}] 的记录吗？",
                "确认删除", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                DeleteInventoryFromDatabase(materialCode);
        }

        private async void DeleteInventoryFromDatabase(string materialCode)
        {
            try
            {
                var sql = "DELETE FROM 库存 WHERE 物料编码=@MaterialCode";
                var parameters = new[] { new SqliteParameter("@MaterialCode", materialCode) };
                await Task.Run(() => DbHelper.ExecuteNonQuery(sql, parameters));
                MessageBox.Show("库存记录删除成功！", "成功", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadDataAsync();
            }
            catch (Exception ex) { MessageBox.Show("删除失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error); }
        }
    }
}
